Quick start of meetings in Zoom

Version 3.1.1

06.05.2022 makcum15@mail.ru


================================English (Translated from Russian by DeepL.com)=======================================

zlm.exe - the main program for starting meetings.
zlmwc.exe - the program for starting meetings via a browser (Web client).
Shortcut_Maker.exe - an assistant for creating meeting shortcuts.
zlm_up.exe - program update module

--Installation--

Run setup_zlm.exe and follow the instructions.
Password: zoom

--Use--

Start the Zoom Launcher Meeting - Shortcut Maker.

Then you need to enter a meeting name in the first text box,
In the second textbox, enter a meeting number or simply paste in an invitation link.

NOTE that the meeting number must not contain spaces, and the link does not need to be pre-edited.

--Manually create shortcuts--

To start a particular meeting, you can simply create a shortcut to zlm.exe with a key containing the meeting number.

For example, to start a meeting with number 1234567890, create a shortcut for zlm.exe,
Then in the shortcut properties, in the "Object" field after the closing quotation marks you need to add the meeting number after the space and slash ( /).
That is the line should look like this:
"C:\папка_с_программой\zlm.exe" /1234567890

There is also a way to start the meeting with specified password. To do this, you need to copy the invitation link,
edit it to the form /1234567890?pwd=hash_password and paste into shortcut properties in the object field.

--Debug mode.

The program has a so called Debug mode, which displays a window with the meeting address processing and
followed by the start of Zoom.
To start in this mode, the key -debug must be specified

--History--
1.0 - Startup by meeting number
1.1 - Error fixing.
1.2 - Added shortcut assistant

2.0 - Added support for invitation links in the Assistant, Bug fixing
2.1 - Small fixes
2.2 - Changes in the Assistant: improved checking for errors in meeting number and invitation link.
2.3 - Assistant Changes: fix invitation link definition.
2.4 - Assistant Changes: added validation for invitation link, fixes installer fixes
2.5 - Change in Wizard: fixed Russian text display in non-Russian versions of Windows
2.5.1 - Small fixes
2.6 - Added icons for shortcuts
2.6.1 - Update module added
2.6.2 - Bug fixes
3.0* - Added meeting launcher for web browsers (useful if you don't have Zoom installed), Added Unicode support
3.0.1* - Changed algorithm for creating shortcuts for web client. New versions checking module has been updated.
3.0.2* - Optimization and small fixes.
3.1* - Progress window when starting the meeting.
3.1.1* - Bug with displaying JS error window fixed.
*Unfortunately, I had to temporarily disable icon selection when creating a shortcut. But the icon can be selected in the properties of the shortcut.


==================================== Русский =======================================

Быстрый запуск конференций в Zoom

zlm.exe - основная программа для запуска конференций.
zlmwc.exe - программа для запуска конференций через браузер (Веб клиент).
Shortcut_Maker.exe - помощник по созданию ярлыков конференции.
zlm_up.exe - модуль обновления программы

--Установка--

Запустить setup_zlm.exe и следовать инструкциям.
Пароль: zoom

--Использование--

Запустите Zoom Launcher Meeting - Shortcut Maker

Далее нужно указать в первом текстовом поле название конференции,
во втором текстовом поле номер конференции или просто вставить туда ссылку приглашения.

ОБРАТИТЕ ВНИМАНИЕ, что номер конференции не должен содержать пробелов, а ссылку не нужно предварительно редактировать.

--Ручное создание ярлыков--

Для запуска конкретной конференции можно просто создать ярлык для zlm.exe с ключем, содержащим номер конференции.

Например, для запуска конференции с номером 1234567890, создаем ярлык для файла zlm.exe,
далее в свойствах ярлыка, в поле "Объект" после закрывающих кавычек нужно через пробел и слеш ( /) дописать номер конференции.
То есть строка должна выглядеть так:
"C:\папка_с_программой\zlm.exe" /1234567890

Так же предусмотрен запуск конференции с указанным паролем. Для этого нужно скопировать ссылку приглашения,
отредактировать ее до вида /1234567890?pwd=хеш_пароля и вставить в свойствах ярлыка в поле объект.

--Дебаг режим--

В программе имеется так называемый Debug режим, отображающий окно с процессом выполнения обработки адреса конференции и
с последующим запуском Zoom.
Для запуска в этом режиме нужно указать ключ -debug

--История--
1.0 - Запуск по номеру конференции
1.1 - Устранение ошибок
1.2 - Добавлен помощник по созданию ярлыков

2.0 - Добавлена поддержка ссылок приглашений в Помощнике, Устранение багов
2.1 - Мелкие исправления
2.2 - Изменения в помощнике: улучшенная проверка на ошибки в номере конференции и ссылке приглашения.
2.3 - Изменения в помощнике: исправление определения ссылки приглашения.
2.4 - Изменения в помощнике: добавлена проверка на корректность ссылки приглашения, исправления в инсталяторе
2.5 - Изменения в помощнике: исправлено отображение русского текста в нерусских версиях Windows
2.5.1 - Мелкие исправления
2.6 - Добавлены иконки для ярлыков
2.6.1 - Добавлен модуль обновления
2.6.2 - Исправление ошибок
3.0* - Добавлен запуск конференций через веб браузер (пригодится, если не установлен Zoom), Добавлена поддержка Unicode
3.0.1* - Изменен алгоритм создания ярлыков для веб клиента. Обновлен модуль проверки новых версий.
3.0.2* - Оптимизация и мелкие исправления.
3.1* - Окно прогресса при запуске конференции.
3.1.1* - Исправлен баг с показом окна об ошибках JS
*К сожалению, пришлось временно отключить выбор значков при создании ярлыка. Но значок можно выбрать в свойствах ярлыка.